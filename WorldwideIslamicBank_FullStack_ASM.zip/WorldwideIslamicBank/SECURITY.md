# Security / production boundary

This package is a reference prototype, not deployable banking infrastructure.

Before any real use:
- replace demo authentication with phishing-resistant MFA and a hardened identity provider
- use PostgreSQL with strict roles, transactions, backups and point-in-time recovery
- make the ledger append-only at the database privilege layer
- enforce idempotency keys, deterministic lock ordering and concurrency tests
- use HSM/KMS-backed keys, TLS, key rotation and secrets management
- add KYC/AML/sanctions screening, transaction monitoring and suspicious-activity workflows
- add maker-checker approval and segregation of duties
- independently review Shariah product structures and governance
- implement jurisdiction-specific reporting, consumer protection and licensing requirements
- conduct threat modelling, SAST/DAST, dependency scanning, penetration testing and disaster-recovery exercises

Financial correctness should be independently verified. OWASP specifically recommends database-level concurrency controls for race-sensitive operations. See the project README for the accounting model.
