# Worldwide Islamic Bank — Full-Stack ASM Reference Prototype

A runnable educational/reference prototype for an Islamic banking platform.

Important: this is **not production banking software** and does not constitute regulatory, Shariah, legal, custody, AML/KYC, payments, or security certification. A real bank requires licensed banking infrastructure, independent Shariah governance, compliance controls, audited cryptography, penetration testing, disaster recovery, segregation of duties, and jurisdiction-specific regulatory approval.

## Stack
- Frontend: vanilla HTML/CSS/JavaScript
- Backend: Python standard-library HTTP API
- Database: SQLite
- ASM: x86-64 NASM reference routines for integer/fixed-point accounting checks
- Docker: optional containerization

## Accounting model
The prototype uses integer minor units rather than floating point. Transfers are represented as balanced double-entry journal entries:
- debit source account
- credit destination account
- total debits == total credits

No interest/riba feature is implemented. The demo labels the product as a Shariah-oriented prototype, not a religious ruling.

## Run
```bash
python3 backend/server.py
```
Then open http://localhost:8080

NASM reference:
```bash
nasm -f elf64 asm/ledger.asm -o asm/ledger.o
```

This repository intentionally uses a simple local database and demo authentication. Do not expose it to the public internet.
