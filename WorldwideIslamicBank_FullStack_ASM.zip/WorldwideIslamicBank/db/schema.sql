-- Canonical schema for the demo.
-- Production systems should use PostgreSQL and migrations.
CREATE TABLE users(id BIGSERIAL PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL);
CREATE TABLE accounts(id BIGSERIAL PRIMARY KEY,user_id BIGINT NOT NULL REFERENCES users(id),name TEXT NOT NULL,currency CHAR(3) NOT NULL,balance_minor BIGINT NOT NULL DEFAULT 0);
CREATE TABLE journals(id BIGSERIAL PRIMARY KEY,reference TEXT UNIQUE NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),description TEXT NOT NULL);
CREATE TABLE entries(id BIGSERIAL PRIMARY KEY,journal_id BIGINT NOT NULL REFERENCES journals(id),account_id BIGINT NOT NULL REFERENCES accounts(id),side TEXT NOT NULL CHECK(side IN('DEBIT','CREDIT')),amount_minor BIGINT NOT NULL CHECK(amount_minor>0));
