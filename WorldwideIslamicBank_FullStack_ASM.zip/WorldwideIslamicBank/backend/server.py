#!/usr/bin/env python3
import json, sqlite3, secrets, hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB = ROOT / "db" / "bank.sqlite3"
STATIC = ROOT / "frontend"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    c = db()
    c.executescript("""
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer'
    );
    CREATE TABLE IF NOT EXISTS accounts(
      id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL,
      name TEXT NOT NULL, currency TEXT NOT NULL,
      balance_minor INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS journals(
      id INTEGER PRIMARY KEY, reference TEXT UNIQUE NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      description TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS entries(
      id INTEGER PRIMARY KEY, journal_id INTEGER NOT NULL,
      account_id INTEGER NOT NULL, side TEXT NOT NULL,
      amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
      FOREIGN KEY(journal_id) REFERENCES journals(id),
      FOREIGN KEY(account_id) REFERENCES accounts(id)
    );
    """)
    if not c.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        ph = hashlib.sha256(b"DemoPass123!").hexdigest()
        c.execute("INSERT INTO users(email,password_hash,role) VALUES(?,?,?)",
                  ("demo@example.com", ph, "customer"))
        uid = c.execute("SELECT id FROM users WHERE email='demo@example.com'").fetchone()[0]
        c.execute("INSERT INTO accounts(user_id,name,currency,balance_minor) VALUES(?,?,?,?)",
                  (uid,"Demo Mudarabah Account","GBP",100000))
        c.execute("INSERT INTO accounts(user_id,name,currency,balance_minor) VALUES(?,?,?,?)",
                  (uid,"Demo Sadaqah Account","GBP",0))
    c.commit(); c.close()

def json_response(h, code, obj):
    raw=json.dumps(obj).encode()
    h.send_response(code); h.send_header("Content-Type","application/json")
    h.send_header("Content-Length",str(len(raw))); h.end_headers(); h.wfile.write(raw)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): pass
    def do_GET(self):
        if self.path == "/api/health":
            return json_response(self,200,{"status":"ok","name":"Worldwide Islamic Bank"})
        if self.path == "/api/accounts":
            c=db(); rows=c.execute("SELECT id,name,currency,balance_minor FROM accounts ORDER BY id").fetchall()
            c.close(); return json_response(self,200,{"accounts":[dict(r) for r in rows]})
        if self.path in ("/","/index.html"):
            p=STATIC/"index.html"; data=p.read_bytes()
            self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
        p=STATIC/self.path.lstrip("/")
        if p.exists() and p.is_file():
            data=p.read_bytes(); self.send_response(200)
            self.send_header("Content-Type","text/plain; charset=utf-8" if p.suffix==".js" else "text/css")
            self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
        json_response(self,404,{"error":"not found"})

    def do_POST(self):
        if self.path != "/api/transfers":
            return json_response(self,404,{"error":"not found"})
        try:
            n=int(self.headers.get("Content-Length","0")); body=json.loads(self.rfile.read(n))
            src=int(body["from_account"]); dst=int(body["to_account"]); amount=int(body["amount_minor"])
            if src==dst or amount<=0: raise ValueError("invalid transfer")
        except Exception as e:
            return json_response(self,400,{"error":str(e)})
        c=db()
        try:
            c.execute("BEGIN IMMEDIATE")
            a=c.execute("SELECT * FROM accounts WHERE id=?",(src,)).fetchone()
            b=c.execute("SELECT * FROM accounts WHERE id=?",(dst,)).fetchone()
            if not a or not b: raise ValueError("account not found")
            if a["currency"] != b["currency"]: raise ValueError("currency mismatch")
            if a["balance_minor"] < amount: raise ValueError("insufficient funds")
            ref=secrets.token_hex(16)
            c.execute("UPDATE accounts SET balance_minor=balance_minor-? WHERE id=?",(amount,src))
            c.execute("UPDATE accounts SET balance_minor=balance_minor+? WHERE id=?",(amount,dst))
            j=c.execute("INSERT INTO journals(reference,description) VALUES(?,?)",
                        (ref,"Internal transfer")).lastrowid
            c.execute("INSERT INTO entries(journal_id,account_id,side,amount_minor) VALUES(?,?,?,?)",(j,src,"DEBIT",amount))
            c.execute("INSERT INTO entries(journal_id,account_id,side,amount_minor) VALUES(?,?,?,?)",(j,dst,"CREDIT",amount))
            c.commit()
            return json_response(self,201,{"reference":ref,"status":"posted"})
        except Exception as e:
            c.rollback(); return json_response(self,400,{"error":str(e)})
        finally: c.close()

if __name__=="__main__":
    init()
    print("Worldwide Islamic Bank demo: http://localhost:8080")
    ThreadingHTTPServer(("0.0.0.0",8080),Handler).serve_forever()
