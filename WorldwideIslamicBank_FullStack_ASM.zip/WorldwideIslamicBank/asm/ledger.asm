; x86-64 NASM reference routines for fixed-point ledger arithmetic.
; System V ABI. These routines are deliberately small and side-effect free.

global add_minor
global subtract_if_sufficient
global balanced

section .text

; uint64_t add_minor(uint64_t a, uint64_t b)
add_minor:
    mov rax, rdi
    add rax, rsi
    jc .overflow
    ret
.overflow:
    xor eax, eax
    ret

; int subtract_if_sufficient(uint64_t balance, uint64_t amount)
; returns 1 if sufficient, 0 otherwise; does not mutate storage.
subtract_if_sufficient:
    cmp rdi, rsi
    jb .no
    mov eax, 1
    ret
.no:
    xor eax, eax
    ret

; int balanced(uint64_t debits, uint64_t credits)
balanced:
    cmp rdi, rsi
    sete al
    movzx eax, al
    ret
