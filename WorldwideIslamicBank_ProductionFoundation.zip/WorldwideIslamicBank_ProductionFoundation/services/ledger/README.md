# Ledger service

Canonical production design:

journal(id, reference, created_at, description, status)
journal_entry(id, journal_id, account_id, side, amount_minor, currency)

Invariants:
1. amount_minor > 0
2. every journal has >= 2 entries
3. SUM(DEBIT) == SUM(CREDIT)
4. all entries in a journal share the settlement currency unless an explicitly
   modelled FX journal is used
5. posted journals are immutable
6. corrections are compensating journals, never destructive updates
7. idempotency keys prevent duplicate commands
8. balance projections are derived from posted entries and reconciled
