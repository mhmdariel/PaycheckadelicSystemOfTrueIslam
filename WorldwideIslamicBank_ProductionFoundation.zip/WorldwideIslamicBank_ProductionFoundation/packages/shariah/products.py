from dataclasses import dataclass
from enum import Enum

class ProductType(str, Enum):
    MURABAHA = "murabaha"
    MUDARABAH = "mudarabah"
    MUSHARAKAH = "musharakah"
    IJARAH = "ijarah"
    QARD_HASAN = "qard_hasan"

@dataclass(frozen=True)
class ProductApproval:
    product: ProductType
    approval_reference: str
    approved_by: str
    approved_at: str

# This package records governance metadata; it does not issue religious rulings.
