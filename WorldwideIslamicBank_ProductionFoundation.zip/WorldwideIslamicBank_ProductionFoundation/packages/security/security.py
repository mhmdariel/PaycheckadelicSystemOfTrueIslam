from argon2 import PasswordHasher
ph = PasswordHasher()

def hash_password(password: str) -> str:
    return ph.hash(password)

def verify_password(encoded: str, password: str) -> bool:
    try:
        return ph.verify(encoded, password)
    except Exception:
        return False
