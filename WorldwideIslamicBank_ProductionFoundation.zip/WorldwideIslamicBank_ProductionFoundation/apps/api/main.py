from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from decimal import Decimal
from uuid import UUID, uuid4
from datetime import datetime, timezone

app = FastAPI(title="Worldwide Islamic Bank API", version="0.1.0")

# Reference in-memory adapter. Production deployment MUST use PostgreSQL,
# durable transactions, a secrets manager/HSM, and real identity/compliance services.

accounts = {
    "00000000-0000-0000-0000-000000000001": {"currency": "GBP", "balance_minor": 100000},
    "00000000-0000-0000-0000-000000000002": {"currency": "GBP", "balance_minor": 0},
}
idempotency = {}
journal = []

class Transfer(BaseModel):
    from_account: UUID
    to_account: UUID
    amount_minor: int = Field(gt=0, le=10_000_000_000)
    currency: str = Field(min_length=3, max_length=3)
    purpose: str = Field(min_length=1, max_length=500)

@app.get("/health")
def health():
    return {"status": "ok", "service": "Worldwide Islamic Bank API"}

@app.get("/v1/accounts")
def list_accounts():
    return [{"id": k, **v} for k, v in accounts.items()]

@app.post("/v1/transfers", status_code=201)
def transfer(cmd: Transfer, idempotency_key: str = Header(..., min_length=16)):
    if idempotency_key in idempotency:
        return idempotency[idempotency_key]

    src, dst = str(cmd.from_account), str(cmd.to_account)
    if src == dst:
        raise HTTPException(400, "Source and destination must differ")
    if src not in accounts or dst not in accounts:
        raise HTTPException(404, "Account not found")
    if accounts[src]["currency"] != cmd.currency or accounts[dst]["currency"] != cmd.currency:
        raise HTTPException(400, "Currency mismatch")
    if accounts[src]["balance_minor"] < cmd.amount_minor:
        raise HTTPException(409, "Insufficient funds")

    # Production implementation must execute the following as ONE serializable
    # PostgreSQL transaction with deterministic row locks and durable journaling.
    accounts[src]["balance_minor"] -= cmd.amount_minor
    accounts[dst]["balance_minor"] += cmd.amount_minor

    ref = str(uuid4())
    event = {
        "reference": ref,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "currency": cmd.currency,
        "amount_minor": cmd.amount_minor,
        "debit_account": src,
        "credit_account": dst,
        "purpose": cmd.purpose,
        "ledger_status": "POSTED",
    }
    journal.append(event)
    idempotency[idempotency_key] = event
    return event
