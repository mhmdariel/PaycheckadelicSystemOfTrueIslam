# Web application boundary

This directory is the UI boundary for the bank.

The production UI should be implemented with:
- TypeScript
- Next.js
- strict CSP
- WebAuthn/passkeys
- server-side session handling
- no secrets in browser code
- accessible customer journeys
- explicit payment confirmation and transaction review
