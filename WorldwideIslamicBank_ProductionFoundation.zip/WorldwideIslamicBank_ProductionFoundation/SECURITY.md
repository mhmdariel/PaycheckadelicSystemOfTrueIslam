# Security baseline

Required before production:
- threat modelling
- secure SDLC
- SAST/DAST/dependency scanning
- independent penetration testing
- WebAuthn/passkeys and phishing-resistant MFA
- HSM/KMS-backed keys
- TLS 1.3 where supported
- database encryption and strict network segmentation
- least-privilege IAM/PAM
- immutable/tamper-evident audit logs
- SIEM and 24/7 incident response
- rate limits, fraud detection and transaction monitoring
- tested backup/PITR and disaster recovery
- RTO/RPO targets
- secrets rotation
- supply-chain signing and provenance
- dual-control for privileged financial operations
