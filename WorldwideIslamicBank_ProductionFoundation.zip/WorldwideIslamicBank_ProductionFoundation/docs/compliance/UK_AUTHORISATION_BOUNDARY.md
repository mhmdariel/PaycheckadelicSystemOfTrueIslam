# UK authorisation boundary

If Worldwide Islamic Bank is intended to operate as a UK bank, the software
does not itself provide authorisation.

The PRA/FCA new-bank process includes pre-application engagement, application,
assessment and potentially mobilisation. The applicant must demonstrate that
it meets the applicable regulatory standards and has the necessary operational
arrangements.

The production programme therefore needs separate workstreams for:
- legal entity and ownership
- capital and liquidity
- governance and SMF responsibilities
- regulatory business plan
- risk management
- financial crime/AML
- customer protection and complaints
- operational resilience
- technology and cyber controls
- outsourcing
- safeguarding/segregation where applicable
- regulatory reporting
- independent assurance
- Shariah governance

Do not accept customer deposits or perform regulated activities until the
required permissions are in place.
