# Shariah governance boundary

The platform supports Islamic-finance product metadata and auditability.

It does not claim that software can determine a religious ruling. Each product
should have:
- a defined contractual structure
- independent Shariah review
- documented approval
- named governance authority
- versioned terms
- change-control and reapproval
- post-launch Shariah audit
