CREATE TABLE accounts (
 id UUID PRIMARY KEY,
 customer_id UUID NOT NULL,
 account_number TEXT UNIQUE NOT NULL,
 currency CHAR(3) NOT NULL,
 status TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ledger_journals (
 id UUID PRIMARY KEY,
 reference TEXT UNIQUE NOT NULL,
 description TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('PENDING','POSTED','REVERSED')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ledger_entries (
 id UUID PRIMARY KEY,
 journal_id UUID NOT NULL REFERENCES ledger_journals(id),
 account_id UUID NOT NULL REFERENCES accounts(id),
 side TEXT NOT NULL CHECK(side IN ('DEBIT','CREDIT')),
 amount_minor BIGINT NOT NULL CHECK(amount_minor > 0),
 currency CHAR(3) NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX ledger_entries_account_idx ON ledger_entries(account_id, created_at);
CREATE INDEX ledger_entries_journal_idx ON ledger_entries(journal_id);
