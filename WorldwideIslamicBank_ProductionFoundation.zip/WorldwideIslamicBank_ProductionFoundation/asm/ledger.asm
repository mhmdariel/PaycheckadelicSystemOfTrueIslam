; Worldwide Islamic Bank - deterministic x86-64 reference primitives
; NASM, System V ABI. Not a cryptographic implementation.

global wb_add_u64
global wb_can_debit
global wb_balanced

section .text

wb_add_u64:
    mov rax, rdi
    add rax, rsi
    jc .overflow
    ret
.overflow:
    xor eax, eax
    ret

wb_can_debit:
    cmp rdi, rsi
    setae al
    movzx eax, al
    ret

wb_balanced:
    cmp rdi, rsi
    sete al
    movzx eax, al
    ret
