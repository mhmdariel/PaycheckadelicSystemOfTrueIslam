NASM reference build:

nasm -f elf64 asm/ledger.asm -o asm/ledger.o

The high-level ledger must remain authoritative. Assembly is only appropriate
where it gives a measurable, audited benefit and must have equivalent reference
implementations and test vectors.
