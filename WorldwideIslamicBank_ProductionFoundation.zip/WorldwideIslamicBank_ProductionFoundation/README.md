# Worldwide Islamic Bank — Production Foundation

This repository is a production-oriented foundation for **Worldwide Islamic Bank**.
It is intentionally NOT represented as a licensed/authorised bank. Software cannot itself confer banking authorisation.

## Architecture
- API service: FastAPI
- Web app: Next.js-compatible TypeScript starter
- Ledger service: PostgreSQL-oriented double-entry design
- Worker: asynchronous compliance/event processing boundary
- Security package: password hashing, token primitives, security headers
- Shariah package: product-contract metadata boundary; religious rulings must be independently governed
- x86-64 NASM: small deterministic arithmetic primitives
- Docker and Kubernetes deployment skeleton
- Compliance documentation and operational controls checklist

## Local development
1. Install Python 3.12+.
2. `python -m venv .venv && source .venv/bin/activate`
3. `pip install -r apps/api/requirements.txt`
4. `python apps/api/main.py`
5. Open `http://127.0.0.1:8000/docs`

For production, replace development defaults, provision PostgreSQL, managed secrets/HSM/KMS, TLS, observability, WAF/API gateway, CI/CD and the external compliance/payment providers.

## Banking boundary
The system is designed so that:
- every monetary movement is represented by balanced debit/credit entries;
- balances are integer minor units;
- idempotency is mandatory for payment commands;
- privileged actions are approval-gated;
- customer funds are separated conceptually from bank/general-ledger accounts;
- compliance and Shariah governance remain explicit control planes.

## UK authorisation
If operating from the UK as a bank, the applicant must obtain the appropriate PRA authorisation with FCA consent and satisfy the applicable threshold conditions. This repository is not an application for authorisation and does not substitute for regulatory, legal, compliance, audit, capital, liquidity or governance work.

## Production readiness
Before live customer funds:
- independent security review and penetration test
- threat model and secure SDLC
- formal ledger/property-based/concurrency testing
- HSM/KMS and key ceremonies
- production IAM/MFA/PAM
- KYC/AML/sanctions integrations
- transaction monitoring and case management
- safeguarding/segregation and reconciliation
- operational resilience and disaster recovery
- regulatory reporting
- Shariah supervisory governance and product approvals
- licensing, capital and liquidity plan
